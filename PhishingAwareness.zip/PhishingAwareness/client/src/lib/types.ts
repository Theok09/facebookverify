export interface AlertInfo {
  location: string;
  device: string;
  time: string;
}
